 
alter table csh_transaction add (fee_type varchar2(30));
  
alter table csh_transaction_wfl add (fee_type varchar2(30));
